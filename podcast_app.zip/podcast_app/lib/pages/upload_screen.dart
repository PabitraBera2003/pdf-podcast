import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:dio/dio.dart';
import 'package:podcast_app/pages/result_screen.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  File? file;
  bool loading = false;

  final Dio dio = Dio();

  static const String apiUrl = "https://pdf-podcast.onrender.com/generate";

  Future<void> pickPdf() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      file = File(result.files.single.path!);
      setState(() {});
    }
  }

  Future<void> upload() async {
    if (file == null) return;

    setState(() => loading = true);

    try {
      FormData formData = FormData.fromMap({
        "file": await MultipartFile.fromFile(
          file!.path,
          filename: file!.path.split('/').last,
        ),
      });

      Response response = await dio.post(apiUrl, data: formData);

      if (mounted) {
        setState(() => loading = false);
      }

      if (response.data != null && response.data["status"] == true) {
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ResultScreen(
                script: response.data["script"],
                audioFile: response.data["audio_file"],
              ),
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                response.data?["message"] ?? "An unknown error occurred.",
              ),
            ),
          );
        }
      }
    } on DioException catch (e) {
      if (mounted) {
        setState(() => loading = false);
        String errorMessage = "Failed to generate podcast.";
        if (e.response != null &&
            e.response?.data != null &&
            e.response?.data is Map) {
          errorMessage = e.response!.data["message"] ?? e.message;
        } else if (e.message != null) {
          errorMessage = e.message!;
        }

        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errorMessage)));
      }
    } catch (e) {
      if (mounted) {
        setState(() => loading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Podify AI")),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0A0E21), Color(0xFF1A1A3A)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.podcasts_rounded,
                size: 80,
                color: Color(0xFF6C63FF),
              ),
              const SizedBox(height: 24),
              const Text(
                "Turn Documents into\nEngaging Podcasts",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  height: 1.2,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "Upload a PDF and let AI narrate it for you.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white.withOpacity(0.7),
                ),
              ),
              const SizedBox(height: 48),
              GestureDetector(
                onTap: loading ? null : pickPdf,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D1E33).withOpacity(0.8),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFF6C63FF).withOpacity(0.5),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF6C63FF).withOpacity(0.1),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Icon(
                        file != null ? Icons.picture_as_pdf : Icons.upload_file,
                        size: 60,
                        color: file != null
                            ? const Color(0xFFFF6584)
                            : const Color(0xFF6C63FF),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        file != null
                            ? file!.path.split(Platform.pathSeparator).last
                            : "Tap to browse PDF",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),
              if (loading)
                Column(
                  children: [
                    const CircularProgressIndicator(color: Color(0xFFFF6584)),
                    const SizedBox(height: 16),
                    Text(
                      "Generating Podcast...",
                      style: TextStyle(color: Colors.white.withOpacity(0.8)),
                    ),
                  ],
                )
              else
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: file == null ? null : upload,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF6584),
                      shadowColor: const Color(0xFFFF6584).withOpacity(0.5),
                    ),
                    child: const Text(
                      "Generate Podcast",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
