import 'dart:io';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class ResultScreen extends StatefulWidget {
  final String script;
  final String audioFile;

  const ResultScreen({
    super.key,
    required this.script,
    required this.audioFile,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final AudioPlayer player = AudioPlayer();
  bool playing = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  List<String> _sentences = [];
  List<int> _sentenceCharOffsets = [];

  static const String streamBase = "https://pdf-podcast.onrender.com/stream/";

  @override
  void initState() {
    super.initState();

    final matches = RegExp(r'[^.!?\n]+[.!?\n]*\s*').allMatches(widget.script);
    int currentOffset = 0;
    for (var m in matches) {
      final s = m.group(0)!;
      _sentences.add(s);
      currentOffset += s.length;
      _sentenceCharOffsets.add(currentOffset);
    }

    player.onPlayerStateChanged.listen((state) {
      if (mounted && state == PlayerState.completed) {
        setState(() => playing = false);
      }
    });

    player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _position = p);
    });

    player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _duration = d);
    });
  }

  Future<void> toggle() async {
    if (playing) {
      await player.pause();
    } else {
      await player.play(UrlSource(streamBase + widget.audioFile));
    }
    setState(() => playing = !playing);
  }

  Future<void> skipForward() async {
    final currentPos = await player.getCurrentPosition();
    if (currentPos != null) {
      final newPos = currentPos + const Duration(seconds: 10);
      await player.seek(newPos);
    }
  }

  Future<void> skipBackward() async {
    final currentPos = await player.getCurrentPosition();
    if (currentPos != null) {
      var newPos = currentPos - const Duration(seconds: 10);
      if (newPos.isNegative) newPos = Duration.zero;
      await player.seek(newPos);
    }
  }

  Future<void> _downloadPdf() async {
    try {
      final pdf = pw.Document();

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return [
              pw.Header(
                level: 0,
                child: pw.Text(
                  "Podcast Transcript",
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.Paragraph(
                margin: const pw.EdgeInsets.only(top: 20),
                text: widget.script,
                style: const pw.TextStyle(fontSize: 12, lineSpacing: 2),
              ),
            ];
          },
        ),
      );

      final bytes = await pdf.save();

      String? outputFile = await FilePicker.platform.saveFile(
        dialogTitle: 'Save Transcript PDF',
        fileName: 'podcast_transcript.pdf',
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        bytes: bytes,
      );

      if (outputFile == null) return;

      if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
        if (!outputFile.endsWith(".pdf")) {
          outputFile += ".pdf";
        }
        final file = File(outputFile);
        await file.writeAsBytes(bytes);
      }

      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Saved to $outputFile")));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Failed to save: $e")));
      }
    }
  }

  void _showFullScreenTranscript() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(
            title: const Text("Full Transcript"),
            backgroundColor: const Color(0xFF0A0E21),
            elevation: 0,
          ),
          body: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF0A0E21), Color(0xFF1A1A3A)],
              ),
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: _buildRichLyrics(),
            ),
          ),
        ),
      ),
    );
  }

  String formatDuration(Duration d) {
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$minutes:$seconds";
  }

  int _getActiveSentenceIndex() {
    if (_duration.inMilliseconds == 0 || widget.script.isEmpty) return 0;
    final progressFraction =
        _position.inMilliseconds / _duration.inMilliseconds;
    final targetOffset = progressFraction * widget.script.length;

    for (int i = 0; i < _sentenceCharOffsets.length; i++) {
      if (targetOffset <= _sentenceCharOffsets[i]) {
        return i;
      }
    }
    return _sentences.length - 1;
  }

  Widget _buildRichLyrics() {
    final activeIndex = _getActiveSentenceIndex();
    return RichText(
      text: TextSpan(
        children: List.generate(_sentences.length, (index) {
          final isActive = index == activeIndex;
          return TextSpan(
            text: _sentences[index],
            style: TextStyle(
              fontSize: 18,
              height: 1.6,
              color: isActive ? Colors.white : Colors.white24,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            ),
          );
        }),
      ),
    );
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Your Podcast")),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A0E21), Color(0xFF1A1A3A)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              // Now Playing Artwork Card
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C63FF), Color(0xFFFF6584)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF6584).withOpacity(0.4),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(
                    Icons.headphones_rounded,
                    size: 80,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 32),

              // Progress Bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  children: [
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: const Color(0xFFFF6584),
                        inactiveTrackColor: Colors.white24,
                        thumbColor: const Color(0xFFFF6584),
                        overlayColor: const Color(0xFFFF6584).withOpacity(0.2),
                        trackHeight: 4.0,
                        thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 6.0,
                        ),
                      ),
                      child: Slider(
                        min: 0,
                        max: _duration.inSeconds.toDouble() > 0
                            ? _duration.inSeconds.toDouble()
                            : 1.0,
                        value: _position.inSeconds.toDouble().clamp(
                          0.0,
                          _duration.inSeconds.toDouble() > 0
                              ? _duration.inSeconds.toDouble()
                              : 1.0,
                        ),
                        onChanged: (value) async {
                          final position = Duration(seconds: value.toInt());
                          await player.seek(position);
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          formatDuration(_position),
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                        Text(
                          formatDuration(_duration),
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Player Controls
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: skipBackward,
                    icon: const Icon(Icons.replay_10_rounded),
                    color: Colors.white70,
                    iconSize: 36,
                  ),
                  const SizedBox(width: 24),
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFFFF6584),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF6584).withOpacity(0.5),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: IconButton(
                      onPressed: toggle,
                      icon: Icon(
                        playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                      ),
                      color: Colors.white,
                      iconSize: 48,
                      padding: const EdgeInsets.all(16),
                    ),
                  ),
                  const SizedBox(width: 24),
                  IconButton(
                    onPressed: skipForward,
                    icon: const Icon(Icons.forward_10_rounded),
                    color: Colors.white70,
                    iconSize: 36,
                  ),
                ],
              ),
              const SizedBox(height: 40),

              const Divider(color: Colors.white24),
              const SizedBox(height: 16),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Transcript",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1.1,
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        onPressed: _downloadPdf,
                        icon: const Icon(Icons.download_rounded),
                        color: Colors.white70,
                      ),
                      IconButton(
                        onPressed: _showFullScreenTranscript,
                        icon: const Icon(Icons.fullscreen_rounded),
                        color: Colors.white70,
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Script Container
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D1E33).withOpacity(0.6),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: SingleChildScrollView(child: _buildRichLyrics()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
